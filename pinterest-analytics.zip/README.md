# Pinterest Analytics Tool

A tool to fetch board and pin count of any Pinterest user using Playwright and Flask.

## Run locally

```bash
pip install -r requirements.txt
playwright install
python run.py
```

## Deploy on Render

Supports render.com with build instructions in render.yaml.
