from playwright.sync_api import sync_playwright

def get_pinterest_data(username):
    url = f'https://www.pinterest.com/{username}/'
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto(url, timeout=60000)
        page.wait_for_selector('a[href*="/{}/"]'.format(username), timeout=10000)

        board_elements = page.query_selector_all(f'a[href*="/{username}/"]')
        board_links = []
        board_names = []

        for el in board_elements:
            href = el.get_attribute("href")
            title = el.inner_text().strip()
            if href and f"/{username}/" in href and title:
                board_links.append("https://www.pinterest.com" + href)
                board_names.append(title)

        total_boards = len(board_links)
        total_pins = 0

        for board_url in board_links:
            page.goto(board_url)
            page.wait_for_timeout(1000)

            for _ in range(3):
                page.mouse.wheel(0, 5000)
                page.wait_for_timeout(1000)

            pins = page.query_selector_all('div[data-test-id="pin"]')
            total_pins += len(pins)

        browser.close()
    return total_boards, total_pins, board_names
