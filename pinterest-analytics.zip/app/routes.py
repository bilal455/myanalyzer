from flask import Blueprint, render_template, request
from app.scraper import get_pinterest_data

bp = Blueprint('main', __name__)

@bp.route('/', methods=['GET', 'POST'])
def index():
    result = None
    if request.method == 'POST':
        username = request.form['username']
        try:
            boards, pins, board_names = get_pinterest_data(username)
            result = {
                'username': username,
                'boards': boards,
                'pins': pins,
                'board_names': board_names
            }
        except Exception as e:
            result = {'error': str(e)}
    return render_template('index.html', result=result)
